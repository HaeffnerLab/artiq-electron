Example Matlab app to show to use the Time Tagger with a Matlab GUI.

* TTGuiControl: control the Time Tagger channel settings
* TTGuiCorrelation: setup and plot a correlation measurement
* TTGuiCounter: setup and plot a counter measurement

Please modify the code to meet your needs.
